---
name: agenticflow
description: This skill should be used when users want to design, build, or validate AgenticFlow automation workflows. Use this skill when users mention AgenticFlow, automation workflows, or want to integrate external services (Gmail, Slack, Shopify, CRM systems, etc.) into automated processes.
license: Complete terms in LICENSE.txt
---

# AgenticFlow

## When to use this skill

To design, build, or validate AgenticFlow automation workflows:

### Core Workflow Process

To create AgenticFlow workflows, follow this systematic process:

1. **Health Check**: Always start with `agenticflow_health_check()` to verify API connectivity
2. **Discovery**: Analyze user requirements and identify needed nodes/MCP actions
3. **MCP Integration**: Plan external service integrations from 2,500+ available services
4. **Configuration**: Design node configurations and data flow using `{{node_name.field}}` syntax
5. **Building**: Create workflow mixing standard nodes and MCP integrations
6. **Validation**: Test workflow structure and document MCP connection requirements

### Resource Loading Strategy

Load reference files as needed:

1. **For standard nodes**: Load `references/complete_node_types.md` for 40+ node library
2. **For MCP integrations**: Load `references/mcp_integrations.md` for 2,500+ service actions
3. **For workflow patterns**: Load `references/workflow_guide.md` for design patterns
4. **For node selection**: Load `references/node_types.md` for troubleshooting and selection

### Key Mindset

**Think expansively**: AgenticFlow can connect to 2,500+ services through MCP, not just built-in nodes. When users ask about automation capabilities, consider both standard nodes and MCP integrations.

**Example approach**: For "sync Shopify orders to Google Sheets with Slack notifications":
- Use `SHOPIFY-GET-ORDERS` MCP action
- Use `GOOGLE_SHEETS-APPEND-ROW` MCP action
- Use `SLACK-SEND-MESSAGE` MCP action
- Connect with LLM nodes for intelligent processing

## Keywords

AgenticFlow, automation workflows, workflow design, MCP integrations, external services, API automation, workflow validation, workflow building
