# Node Type Selection Guide

## Node Selection Strategy

### When to Use Each Node Type

**For Web Research & Data Collection:**
- `perplexity_search` - When you need AI-powered search with citations
- `google_search` - When you need Google's search results
- `tavily_search` - When you need fast, comprehensive web search
- `web_scraping` - When you need to extract content from specific URLs
- `firecrawl_scrape` - When you need advanced scraping with JavaScript rendering

**For AI Processing & Analysis:**
- `llm` - When you need general AI processing with any model
- `claude_ask` - When you specifically need Claude's capabilities
- `openai_ask_chat_gpt` - When you need ChatGPT for specific tasks
- `openai_ask_assistant` - When you need specialized GPT assistants
- `extract_content` - When you need structured data extraction

**For Data Processing:**
- `openai_extract_structured_data` - When you need reliable JSON extraction
- `claude_extract_structured_data` - When you prefer Claude for extraction
- `string_to_json` - When you need to convert strings to JSON objects
- `get_value_by_key` - When you need to extract specific fields from data

**For Image & Video Processing:**
- `generate_image` - When you need general image generation
- `generate_image_v2` - When you need advanced image generation
- `describe_image` - When you need to analyze and describe images
- `pml_edit_image` - When you need to edit existing images

**For External Service Integration:**
- `mcp_run_action` - When you need to connect to any external service
- `api_call` - When you need to make custom HTTP API calls
- `export_data_to_file` - When you need to save data to files

## Detailed Node Type Reference

### Web Research & Search Nodes

#### perplexity_search
**Use when**: You need AI-powered search with citations and up-to-date information

**Common Configuration:**
```javascript
{
  "name": "search_perplexity",
  "node_type_name": "perplexity_search",
  "input_config": {
    "query": "{{search_query}}",
    "max_results": 5,
    "search_type": "web"  // or "news", "academic"
  }
}
```

**Output Fields:**
- `results` - Array of search results with titles, URLs, and content
- `citations` - Source citations for each result
- `answer` - AI-generated answer to query

#### google_search
**Use when**: You need Google's search results specifically

**Common Configuration:**
```javascript
{
  "name": "search_google",
  "node_type_name": "google_search",
  "input_config": {
    "query": "{{search_query}}",
    "num_results": 10,
    "safe_search": "moderate"
  }
}
```

**Output Fields:**
- `organic_results` - Organic search results
- `paid_results` - Paid advertisements
- `related_questions` - Related search queries

#### tavily_search
**Use when**: You need fast, comprehensive web search

**Common Configuration:**
```javascript
{
  "name": "search_tavily",
  "node_type_name": "tavily_search",
  "input_config": {
    "query": "{{search_query}}",
    "max_results": 10,
    "search_depth": "basic"  // or "advanced"
  }
}
```

**Output Fields:**
- `results` - Search results with titles, URLs, and snippets
- `answer` - Direct answer if available
- `images` - Image results if applicable

### Web Scraping Nodes

#### web_scraping
**Use when**: You need to extract content from specific web pages

**Common Configuration:**
```javascript
{
  "name": "scrape_website",
  "node_type_name": "web_scraping",
  "input_config": {
    "web_url": "{{target_url}}",
    "max_tokens": 10000,
    "include_images": false,
    "include_links": false
  }
}
```

**Output Fields:**
- `scraped_content` - Extracted text content
- `page_title` - Title of the web page
- `url` - URL that was scraped
- `word_count` - Number of words extracted

#### firecrawl_scrape
**Use when**: You need advanced scraping with JavaScript rendering

**Common Configuration:**
```javascript
{
  "name": "scrape_with_js",
  "node_type_name": "firecrawl_scrape",
  "input_config": {
    "url": "{{target_url}}",
    "formats": ["markdown", "html"],
    "include_screenshots": false,
    "wait_time": 2000
  }
}
```

**Output Fields:**
- `markdown` - Content in markdown format
- `html` - Raw HTML content
- `screenshots` - Screenshots if requested
- `metadata` - Page metadata

#### url_to_markdown
**Use when**: You need to convert web pages to clean markdown

**Common Configuration:**
```javascript
{
  "name": "convert_to_markdown",
  "node_type_name": "url_to_markdown",
  "input_config": {
    "url": "{{target_url}}",
    "include_images": false,
    "include_links": true
  }
}
```

**Output Fields:**
- `markdown` - Converted markdown content
- `title` - Page title
- `images` - Image URLs if included
- `links` - Links if included

### AI Processing Nodes

#### llm
**Use when**: You need general AI processing with any model

**Common Configuration:**
```javascript
{
  "name": "process_with_llm",
  "node_type_name": "llm",
  "input_config": {
    "model": "DeepSeek V3",  // or "Claude 3.5 Sonnet", "GPT-4o-mini"
    "temperature": 0.3,
    "max_tokens": 4000,
    "human_message": "Process this data: {{input_data}}",
    "system_message": "You are an expert analyst..."
  }
}
```

**Available Models:**
- `DeepSeek V3` - Cost-effective, good for simple tasks
- `Claude 3.5 Sonnet` - Advanced reasoning, good for complex analysis
- `GPT-4o-mini` - Fast and capable, good for general tasks
- `GPT-4o` - Most powerful, good for complex reasoning

**Output Fields:**
- `content` - AI-generated response
- `usage` - Token usage statistics
- `model` - Model used for generation

#### claude_ask
**Use when**: You specifically need Claude's capabilities

**Common Configuration:**
```javascript
{
  "name": "ask_claude",
  "node_type_name": "claude_ask",
  "input_config": {
    "question": "{{user_question}}",
    "context": "{{optional_context}}",
    "model": "claude-3-5-sonnet-20241022"
  }
}
```

**Output Fields:**
- `answer` - Claude's response
- `sources` - Source citations if applicable
- `confidence` - Confidence score for response

#### openai_ask_chat_gpt
**Use when**: You need ChatGPT for specific tasks

**Common Configuration:**
```javascript
{
  "name": "ask_chatgpt",
  "node_type_name": "openai_ask_chat_gpt",
  "input_config": {
    "question": "{{user_question}}",
    "context": "{{optional_context}}",
    "model": "gpt-4o-mini"
  }
}
```

**Output Fields:**
- `response` - ChatGPT's response
- `usage` - Token usage information
- `model` - Model used

### Data Extraction Nodes

#### openai_extract_structured_data
**Use when**: You need reliable JSON extraction from unstructured text

**Common Configuration:**
```javascript
{
  "name": "extract_structured",
  "node_type_name": "openai_extract_structured_data",
  "input_config": {
    "model": "gpt-4o-mini",
    "input_text": "{{unstructured_text}}",
    "json_schema": {
      "type": "object",
      "properties": {
        "name": {"type": "string"},
        "email": {"type": "string"},
        "phone": {"type": "string"}
      },
      "required": ["name", "email"]
    }
  }
}
```

**Output Fields:**
- `extracted_data` - Structured data matching schema
- `confidence` - Confidence score for extraction
- `errors` - Any extraction errors

#### claude_extract_structured_data
**Use when**: You prefer Claude for structured data extraction

**Common Configuration:**
```javascript
{
  "name": "extract_with_claude",
  "node_type_name": "claude_extract_structured_data",
  "input_config": {
    "model": "claude-3-5-sonnet-20241022",
    "input_text": "{{unstructured_text}}",
    "json_schema": {
      "type": "object",
      "properties": {
        "title": {"type": "string"},
        "summary": {"type": "string"},
        "tags": {"type": "array", "items": {"type": "string"}}
      }
    }
  }
}
```

**Output Fields:**
- `structured_data` - Extracted structured data
- `extraction_method` - Method used for extraction
- `confidence` - Confidence score

#### extract_content
**Use when**: You need general content extraction with custom schema

**Common Configuration:**
```javascript
{
  "name": "extract_content",
  "node_type_name": "extract_content",
  "input_config": {
    "content": "{{source_content}}",
    "schema": {
      "type": "object",
      "properties": {
        "main_points": {"type": "array"},
        "key_insights": {"type": "array"},
        "action_items": {"type": "array"}
      }
    }
  }
}
```

**Output Fields:**
- `extracted_content` - Content matching schema
- `quality_score` - Quality of extraction
- `missing_fields` - Any fields that couldn't be extracted

### Image Processing Nodes

#### generate_image
**Use when**: You need general image generation

**Common Configuration:**
```javascript
{
  "name": "create_image",
  "node_type_name": "generate_image",
  "input_config": {
    "prompt": "{{image_description}}",
    "model": "dall-e-3",
    "size": "1024x1024",
    "quality": "standard"  // or "hd"
  }
}
```

**Available Models:**
- `dall-e-3` - OpenAI's DALL-E 3
- `midjourney` - Midjourney integration
- `stable-diffusion` - Stable Diffusion models

**Output Fields:**
- `image_url` - URL to generated image
- `revised_prompt` - Revised prompt if modified
- `image_id` - Image identifier

#### describe_image
**Use when**: You need to analyze and describe images

**Common Configuration:**
```javascript
{
  "name": "analyze_image",
  "node_type_name": "describe_image",
  "input_config": {
    "image_url": "{{image_to_analyze}}",
    "detail_level": "detailed",  // or "basic"
    "include_objects": true,
    "include_text": true
  }
}
```

**Output Fields:**
- `description` - Detailed image description
- `objects` - Objects detected in image
- `text` - Text extracted from image
- `colors` - Dominant colors in image

#### pml_edit_image
**Use when**: You need to edit existing images

**Common Configuration:**
```javascript
{
  "name": "edit_image",
  "node_type_name": "pml_edit_image",
  "input_config": {
    "image_url": "{{source_image}}",
    "edit_prompt": "{{edit_instruction}}",
    "strength": 0.7
  }
}
```

**Output Fields:**
- `edited_image_url` - URL to edited image
- `edit_applied` - Description of edits applied
- `original_image_url` - URL to original image

### API & External Service Nodes

#### api_call
**Use when**: You need to make custom HTTP API calls

**Common Configuration:**
```javascript
{
  "name": "call_api",
  "node_type_name": "api_call",
  "input_config": {
    "url": "{{api_endpoint}}",
    "method": "GET",  // or "POST", "PUT", "DELETE"
    "headers": {
      "Content-Type": "application/json",
      "Authorization": "Bearer {{api_token}}"
    },
    "body": {  // For POST/PUT requests
      "data": "{{request_data}}"
    },
    "response_type": "json"  // or "text", "binary"
  }
}
```

**Output Fields:**
- `response` - API response data
- `status_code` - HTTP status code
- `headers` - Response headers
- `response_time` - API call duration

#### mcp_run_action
**Use when**: You need to connect to any external service via MCP

**Common Configuration:**
```javascript
{
  "name": "run_mcp_action",
  "node_type_name": "mcp_run_action",
  "input_config": {
    "action": "SERVICE-ACTION-NAME",
    "input_params": {
      "instruction": "Execute this action with data: {{previous_node.output}}"
    }
  },
  "connection": "{{__app_connections__['connection-uuid']}}"
}
```

**Output Fields:**
- `output` - Action output data
- `status` - Action execution status
- `error` - Error message if failed
- `execution_time` - Action execution duration

#### export_data_to_file
**Use when**: You need to save data to files

**Common Configuration:**
```javascript
{
  "name": "export_data",
  "node_type_name": "export_data_to_file",
  "input_config": {
    "data": "{{data_to_export}}",
    "filename": "output.json",
    "format": "json"  // or "csv", "txt", "xml"
  }
}
```

**Output Fields:**
- `file_url` - URL to exported file
- `file_size` - Size of exported file
- `download_count` - Number of downloads

## Template Variable Syntax

### Accessing Node Outputs
```javascript
{{node_name.response}}      // API call response
{{node_name.content}}       // LLM output
{{node_name.scraped_content}} // Web scraping result
{{node_name.extracted_data}} // Structured extraction
{{node_name.image_url}}     // Generated image URL
```

### Accessing Input Parameters
```javascript
{{input_parameter_name}}
{{input.query}}
{{input.url}}
```

### Accessing Connections
```javascript
{{__app_connections__['connection-uuid']}}
```

### Nested Field Access
```javascript
{{node_name.response.data.items[0].name}}
{{node_name.extracted_data.results[0].email}}
```

## Common Configuration Patterns

### Error Handling
```javascript
{
  "name": "robust_operation",
  "node_type_name": "llm",
  "input_config": {
    "model": "DeepSeek V3",
    "human_message": "Process this data and handle any errors: {{input_data}}",
    "system_message": "If you encounter errors, provide a helpful error message and suggest alternatives."
  }
}
```

### Data Validation
```javascript
{
  "name": "validate_data",
  "node_type_name": "llm",
  "input_config": {
    "model": "DeepSeek V3",
    "human_message": "Validate this data and return only valid entries: {{input_data}}",
    "system_message": "You are a data validation expert. Remove invalid entries and explain why."
  }
}
```

### Data Transformation
```javascript
{
  "name": "transform_data",
  "node_type_name": "llm",
  "input_config": {
    "model": "Claude 3.5 Sonnet",
    "human_message": "Transform this data into the required format: {{input_data}}",
    "system_message": "You are a data transformation expert. Convert data while preserving all important information."
  }
}
```

## Troubleshooting Common Issues

### Node Configuration Errors
**Problem**: "Required field missing"
**Solution**: Check node type definition and ensure all required fields are provided

**Problem**: "Invalid data type"
**Solution**: Verify field types match expected data (string, number, array, object)

**Problem**: "Template variable not found"
**Solution**: Check node names and field paths for typos

### Performance Issues
**Problem**: "Node execution timeout"
**Solution**: Reduce data size or increase timeout limits

**Problem**: "Memory limit exceeded"
**Solution**: Process data in smaller chunks or use more efficient models

**Problem**: "Rate limit exceeded"
**Solution**: Add delays between operations or use batch processing

### Data Flow Issues
**Problem**: "Empty output from previous node"
**Solution**: Add validation nodes to check data before processing

**Problem**: "Incorrect data format"
**Solution**: Use data transformation nodes to format data correctly

**Problem**: "Missing required fields"
**Solution**: Use data extraction nodes to ensure all fields are present

## Best Practices

### Node Selection
1. **Choose the right tool**: Select nodes based on specific needs
2. **Consider cost**: Use efficient models for simple tasks
3. **Plan data flow**: Ensure output from one node matches input requirements of next
4. **Handle errors**: Include error handling for critical operations

### Configuration Tips
1. **Use descriptive names**: Make node names clear and meaningful
2. **Set appropriate limits**: Configure token limits and timeouts appropriately
3. **Validate inputs**: Check data before processing
4. **Document complex logic**: Add comments for complex configurations

### Performance Optimization
1. **Use efficient models**: Choose appropriate models for task complexity
2. **Batch operations**: Group similar operations when possible
3. **Cache results**: Store frequently used data
4. **Parallel execution**: Run independent nodes simultaneously